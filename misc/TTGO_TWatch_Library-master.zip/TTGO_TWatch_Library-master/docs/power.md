
# About power consumption:
- EN:  Off the screen, turn off WiFi, Bluetooth and other peripherals consume about 4mA (non-deep sleep), turn on the screen power, do not turn on WiFi, Bluetooth and other peripherals around 65mA, please refer to `example -> SimpleWatch` for the specific code.

- CN:  关闭屏幕，关闭WiFi,蓝牙和其他外围设备功耗在4mA左右（非深度睡眠），开屏功耗,不开启WiFi,蓝牙和其他外围设备在65mA左右，具体代码请参考`example -> SimpleWatch`


  ## Off screen power consumption
  ![](../images/off.png)

  ## Open screen power consumption
  ![](../images/on.png)