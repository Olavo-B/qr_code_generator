// => Hardware select
// #define LILYGO_WATCH_2019_WITH_TOUCH     // To use T-Watch2019 with touchscreen, please uncomment this line
// #define LILYGO_WATCH_2019_NO_TOUCH          // To use T-Watch2019 Not touchscreen , please uncomment this line

//No SUPPORT!!!!
// #define LILYGO_WATCH_2020_V1
//No SUPPORT!!!!

#include <LilyGoWatch.h>


